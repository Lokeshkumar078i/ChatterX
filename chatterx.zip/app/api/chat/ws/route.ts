import type { NextRequest } from "next/server"
import { WebSocketServer } from "ws"
import { db } from "@/lib/db"

// WebSocket connections store
const connections = new Map()

// Initialize WebSocket server (only once)
let wss: WebSocketServer

if (!wss) {
  wss = new WebSocketServer({ noServer: true })

  wss.on("connection", (ws, req) => {
    const url = new URL(req.url || "", "http://localhost")
    const userId = url.searchParams.get("userId")
    const friendId = url.searchParams.get("friendId")

    if (!userId || !friendId) {
      ws.close()
      return
    }

    // Store connection
    if (!connections.has(userId)) {
      connections.set(userId, new Map())
    }
    connections.get(userId).set(friendId, ws)

    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString())

        // Save message to database
        const newMessage = await db.message.create({
          data: {
            content: data.content,
            senderId: userId,
            receiverId: friendId,
            seen: false,
          },
        })

        // Send to recipient if online
        if (connections.has(friendId) && connections.get(friendId).has(userId)) {
          const recipientWs = connections.get(friendId).get(userId)
          recipientWs.send(JSON.stringify(newMessage))
        }

        // Send back to sender for confirmation
        ws.send(JSON.stringify(newMessage))
      } catch (error) {
        console.error("WebSocket message error:", error)
      }
    })

    ws.on("close", () => {
      // Remove connection
      if (connections.has(userId)) {
        connections.get(userId).delete(friendId)
        if (connections.get(userId).size === 0) {
          connections.delete(userId)
        }
      }
    })
  })
}

export function GET(req: NextRequest) {
  return new Response(null, {
    status: 101, // Switching protocols
  })
}

