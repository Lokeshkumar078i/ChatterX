import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { searchUsers } from "@/lib/data"

export async function GET(req: NextRequest) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const query = req.nextUrl.searchParams.get("q")

  if (!query) {
    return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
  }

  const users = await searchUsers(query, session.userId)

  return NextResponse.json(users)
}

