import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { getUserProfile } from "@/lib/data"
import { ProfileForm } from "@/components/profile-form"
import { FriendRequests } from "@/components/friend-requests"

export default async function ProfilePage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const user = await getUserProfile(session.userId)

  if (!user) {
    redirect("/login")
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex items-center justify-between py-4">
          <h1 className="text-2xl font-bold">ChatterX</h1>
          <nav className="flex items-center gap-4">
            <a href="/" className="hover:underline">
              Home
            </a>
            <form action="/api/auth/logout" method="POST">
              <button type="submit" className="px-4 py-2 border rounded-md hover:bg-muted">
                Logout
              </button>
            </form>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-6">
          <div className="space-y-6">
            <div className="border rounded-lg overflow-hidden">
              <div className="p-4 border-b bg-muted/50">
                <h2 className="font-semibold">Profile Information</h2>
              </div>
              <div className="p-6">
                <ProfileForm user={user} />
              </div>
            </div>
          </div>
          <div className="space-y-6">
            <div className="border rounded-lg overflow-hidden">
              <div className="p-4 border-b bg-muted/50">
                <h2 className="font-semibold">Friend Requests</h2>
              </div>
              <div className="p-4">
                <FriendRequests userId={user.id} />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

