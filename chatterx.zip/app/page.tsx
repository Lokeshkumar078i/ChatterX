import Link from "next/link"
import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import { Button } from "@/components/ui/button"

export default async function Home() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex items-center justify-between py-4">
          <h1 className="text-2xl font-bold">ChatterX</h1>
          <nav className="flex items-center gap-4">
            <Link href="/profile">Profile</Link>
            <form action="/api/auth/logout" method="POST">
              <Button variant="outline" type="submit">
                Logout
              </Button>
            </form>
          </nav>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-6">
          <div className="border rounded-lg overflow-hidden">
            <div className="p-4 border-b bg-muted/50">
              <h2 className="font-semibold">Friends</h2>
            </div>
            <div className="p-4">
              <div className="relative">
                <input type="text" placeholder="Search friends..." className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm text-muted-foreground">Connect with friends to start chatting</p>
              </div>
            </div>
          </div>
          <div className="border rounded-lg overflow-hidden">
            <div className="p-4 border-b bg-muted/50">
              <h2 className="font-semibold">Select a friend to start chatting</h2>
            </div>
            <div className="flex items-center justify-center h-[400px]">
              <div className="text-center">
                <h3 className="text-lg font-medium">Welcome to ChatterX</h3>
                <p className="text-muted-foreground mt-2">Select a friend from the list to start a conversation</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

